const express = require('express');
const router = express.Router();
const pool = require('../db');
const { requireAdmin, requireUser, optionalUser } = require('../middleware/auth');
const { normalizeSubject } = require('../utils/subjectMap');
const asyncHandler = require('../utils/asyncHandler');

// ===== Admin: manage the syllabus topic list =====

// GET /api/syllabus/admin/list?ministry_id=&grade= — every topic in this
// scope, for the admin edit screen.
router.get('/admin/list', requireAdmin, asyncHandler(async (req, res) => {
  const { ministry_id, grade } = req.query;
  const clauses = [];
  const params = [];
  if (ministry_id) { params.push(ministry_id); clauses.push(`ministry_id = $${params.length}`); }
  if (grade) { params.push(grade); clauses.push(`grade = $${params.length}`); }
  const where = clauses.length ? 'WHERE ' + clauses.join(' AND ') : '';
  const { rows } = await pool.query(
    `SELECT * FROM syllabus_topics ${where} ORDER BY subject, position, id`,
    params
  );
  res.json(rows);
}));

// POST /api/syllabus — add a single topic
router.post('/', requireAdmin, asyncHandler(async (req, res) => {
  const { ministry_id, grade, subject, topic, position, video_url } = req.body;
  if (!subject || !topic) return res.status(400).json({ error: 'বিষয় ও টপিক দিন' });
  const { rows } = await pool.query(
    `INSERT INTO syllabus_topics (ministry_id, grade, subject, topic, position, video_url)
     VALUES ($1,$2,$3,$4,$5,$6) RETURNING *`,
    [ministry_id || null, grade || null, subject, topic, position || 0, video_url || null]
  );
  res.status(201).json(rows[0]);
}));

// POST /api/syllabus/bulk — add many topics at once (one line per topic),
// so a full subject syllabus can be pasted in and added in one go.
// body: { ministry_id, grade, subject, topics: ["টপিক ১", "টপিক ২", ...] }
router.post('/bulk', requireAdmin, asyncHandler(async (req, res) => {
  const { ministry_id, grade, subject, topics } = req.body;
  if (!subject || !Array.isArray(topics) || !topics.length) {
    return res.status(400).json({ error: 'বিষয় ও টপিক তালিকা প্রয়োজন' });
  }

  const client = await pool.connect();
  let added = 0;
  try {
    await client.query('BEGIN');
    const startRes = await client.query(
      `SELECT COALESCE(MAX(position), 0) AS m FROM syllabus_topics
       WHERE ministry_id IS NOT DISTINCT FROM $1 AND grade IS NOT DISTINCT FROM $2 AND subject=$3`,
      [ministry_id || null, grade || null, subject]
    );
    let pos = startRes.rows[0].m;
    for (const t of topics) {
      const text = String(t || '').trim();
      if (!text) continue;
      pos += 1;
      await client.query(
        `INSERT INTO syllabus_topics (ministry_id, grade, subject, topic, position) VALUES ($1,$2,$3,$4,$5)`,
        [ministry_id || null, grade || null, subject, text, pos]
      );
      added++;
    }
    await client.query('COMMIT');
  } catch (err) {
    await client.query('ROLLBACK');
    return res.status(500).json({ error: 'সার্ভার সমস্যা: ' + err.message });
  } finally {
    client.release();
  }
  res.json({ added });
}));

// PUT /api/syllabus/:id — edit a topic
router.put('/:id', requireAdmin, asyncHandler(async (req, res) => {
  const { ministry_id, grade, subject, topic, position, video_url } = req.body;
  if (!subject || !topic) return res.status(400).json({ error: 'বিষয় ও টপিক দিন' });
  const { rows } = await pool.query(
    `UPDATE syllabus_topics SET ministry_id=$1, grade=$2, subject=$3, topic=$4, position=$5, video_url=$6
     WHERE id=$7 RETURNING *`,
    [ministry_id || null, grade || null, subject, topic, position || 0, video_url || null, req.params.id]
  );
  if (!rows.length) return res.status(404).json({ error: 'টপিক পাওয়া যায়নি' });
  res.json(rows[0]);
}));

// DELETE /api/syllabus/:id
router.delete('/:id', requireAdmin, asyncHandler(async (req, res) => {
  await pool.query('DELETE FROM syllabus_topics WHERE id=$1', [req.params.id]);
  res.json({ ok: true });
}));

// ===== Student side =====

// GET /api/syllabus/public?ministry_id=&grade= — topics grouped by subject,
// each marked completed/not for the logged-in user (or all false for a
// guest — still viewable without login, just not checkable).
router.get('/public', optionalUser, asyncHandler(async (req, res) => {
  const { ministry_id, grade } = req.query;
  if (!ministry_id || !grade) {
    return res.status(400).json({ error: 'ministry_id ও grade প্রয়োজন' });
  }
  const userId = req.user ? req.user.id : null;
  const { rows } = await pool.query(
    `SELECT st.id, st.subject, st.topic, st.position,
       (usp.topic_id IS NOT NULL) AS completed
     FROM syllabus_topics st
     LEFT JOIN user_syllabus_progress usp ON usp.topic_id = st.id AND usp.user_id = $3
     WHERE st.ministry_id=$1 AND st.grade=$2
     ORDER BY st.subject, st.position, st.id`,
    [ministry_id, grade, userId]
  );

  const bySubject = {};
  for (const r of rows) {
    if (!bySubject[r.subject]) bySubject[r.subject] = [];
    bySubject[r.subject].push(r);
  }
  const total = rows.length;
  const done = rows.filter(r => r.completed).length;
  res.json({
    subjects: bySubject,
    total_topics: total,
    completed_topics: done,
    percent: total ? Math.round((done / total) * 10000) / 100 : 0
  });
}));


// GET /api/syllabus/public/job-solutions/subjects — five canonical subjects
// that currently have at least one topic, with total topic/question counts.
router.get('/public/job-solutions/subjects', asyncHandler(async (req, res) => {
  const { rows } = await pool.query(`
    SELECT st.subject, COUNT(DISTINCT st.id)::int AS topic_count,
      COUNT(q.id)::int AS question_count
    FROM syllabus_topics st
    LEFT JOIN questions q ON q.topic_id=st.id
    WHERE st.subject IS NOT NULL AND st.subject <> ''
    GROUP BY st.subject
  `);
  const merged = new Map();
  for(const r of rows){
    const subject = normalizeSubject(r.subject);
    if(!subject) continue;
    const old=merged.get(subject)||{subject,topic_count:0,question_count:0};
    old.topic_count += r.topic_count;
    old.question_count += r.question_count;
    merged.set(subject,old);
  }
  res.json([...merged.values()].sort((a,b)=>b.question_count-a.question_count));
}));

// ===== Public: Topic-wise Job Solution =====
// Subject -> Topic -> Video + previous-job questions.
// Answers/explanations are intentionally included because this is a study/solution
// feature, not a live exam.
router.get('/public/job-solutions', asyncHandler(async (req, res) => {
  const canonicalSubject = (req.query.subject || '').trim();
  if (!canonicalSubject) return res.status(400).json({ error: 'বিষয় নির্বাচন করুন' });

  const { rows } = await pool.query(`
    SELECT st.id, st.subject, st.topic, st.position, st.video_url,
      COUNT(q.id)::int AS question_count
    FROM syllabus_topics st
    LEFT JOIN questions q ON q.topic_id = st.id
    WHERE st.subject IS NOT NULL
      AND st.subject <> ''
    GROUP BY st.id
    ORDER BY st.position, st.id
  `);
  const filtered = rows.filter(r => normalizeSubject(r.subject) === canonicalSubject);
  res.json({ subject: canonicalSubject, topics: filtered });
}));

router.get('/public/job-solutions/topic/:id', asyncHandler(async (req, res) => {
  let page = parseInt(req.query.page, 10);
  if (!Number.isFinite(page) || page < 1) page = 1;
  const PAGE_SIZE = 30;

  const topicRes = await pool.query(`
    SELECT st.id, st.subject, st.topic, st.video_url, st.position,
      COUNT(q.id)::int AS question_count
    FROM syllabus_topics st
    LEFT JOIN questions q ON q.topic_id = st.id
    WHERE st.id=$1
    GROUP BY st.id
  `, [req.params.id]);
  if (!topicRes.rows.length) return res.status(404).json({ error: 'টপিক পাওয়া যায়নি' });

  const topic = topicRes.rows[0];
  const total = topic.question_count;
  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));
  if (page > totalPages) page = totalPages;

  const { rows } = await pool.query(`
    SELECT q.id, q.question_text, q.option_a, q.option_b, q.option_c, q.option_d,
      q.correct_option, q.explanation, q.post_name, q.exam_year,
      m.name AS ministry_name,
      COALESCE(
        ARRAY_AGG(DISTINCT e.title) FILTER (WHERE e.id IS NOT NULL),
        ARRAY[]::text[]
      ) AS source_exams
    FROM questions q
    LEFT JOIN ministries m ON m.id=q.ministry_id
    LEFT JOIN exam_questions eq ON eq.question_id=q.id
    LEFT JOIN exams e ON e.id=eq.exam_id
      AND COALESCE(e.is_auto_subject,false)=false
      AND COALESCE(e.is_practice,false)=false
      AND COALESCE(e.is_daily,false)=false
      AND COALESCE(e.is_duel,false)=false
      AND COALESCE(e.is_repeated_bank,false)=false
    WHERE q.topic_id=$1
    GROUP BY q.id, m.name
    ORDER BY q.id ASC
    LIMIT $2 OFFSET $3
  `, [req.params.id, PAGE_SIZE, (page - 1) * PAGE_SIZE]);

  res.json({ topic, page, total_pages: totalPages, total_count: total, questions: rows });
}));

// POST /api/syllabus/:id/toggle — mark a topic done/undone for the logged-in
// user. Toggling, not separate mark/unmark endpoints, since the frontend
// checkbox only ever needs to flip the current state.
router.post('/:id/toggle', requireUser, asyncHandler(async (req, res) => {
  const topicId = req.params.id;
  const existing = await pool.query(
    'SELECT 1 FROM user_syllabus_progress WHERE user_id=$1 AND topic_id=$2',
    [req.user.id, topicId]
  );
  if (existing.rows.length) {
    await pool.query('DELETE FROM user_syllabus_progress WHERE user_id=$1 AND topic_id=$2', [req.user.id, topicId]);
    return res.json({ completed: false });
  }
  await pool.query(
    'INSERT INTO user_syllabus_progress (user_id, topic_id) VALUES ($1,$2) ON CONFLICT DO NOTHING',
    [req.user.id, topicId]
  );
  res.json({ completed: true });
}));

// GET /api/syllabus/me/summary — this user's completion % across every
// ministry+grade that has a syllabus defined, for a "your progress" overview.
router.get('/me/summary', requireUser, asyncHandler(async (req, res) => {
  const { rows } = await pool.query(`
    SELECT st.ministry_id, m.name AS ministry_name, st.grade,
      COUNT(*)::int AS total_topics,
      COUNT(usp.topic_id)::int AS completed_topics
    FROM syllabus_topics st
    LEFT JOIN ministries m ON m.id = st.ministry_id
    LEFT JOIN user_syllabus_progress usp ON usp.topic_id = st.id AND usp.user_id = $1
    GROUP BY st.ministry_id, m.name, st.grade
    ORDER BY m.name, st.grade
  `, [req.user.id]);
  res.json(rows.map(r => ({
    ...r,
    percent: r.total_topics ? Math.round((r.completed_topics / r.total_topics) * 10000) / 100 : 0
  })));
}));

module.exports = router;
