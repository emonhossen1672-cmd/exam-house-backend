// autoInit.js — runs automatically every time the server starts.
// Safe to run repeatedly: uses IF NOT EXISTS / ON CONFLICT DO NOTHING,
// so it won't duplicate anything after the first successful run.
const fs = require('fs');
const path = require('path');
const bcrypt = require('bcryptjs');
const pool = require('./db');
const { ADMIN_USERNAME, ADMIN_PASSWORD, STUDENT_ID_PREFIX } = require('./config');

async function autoInit() {
  try {
    const schema = fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8');
    await pool.query(schema);
    console.log('✅ Tables ready.');

    const existing = await pool.query('SELECT id FROM admin_users WHERE username=$1', [ADMIN_USERNAME]);
    if (existing.rows.length === 0) {
      const hash = await bcrypt.hash(ADMIN_PASSWORD, 10);
      await pool.query('INSERT INTO admin_users (username, password_hash) VALUES ($1,$2)', [ADMIN_USERNAME, hash]);
      console.log(`✅ Admin user created — username: ${ADMIN_USERNAME}`);
    } else {
      console.log('ℹ️ Admin user already exists.');
    }

    // Backfill student_code for any user rows created before this column
    // existed (new registrations/Google sign-ups generate their own in
    // routes/auth.routes.js, so this only ever touches old rows).
    await pool.query(
      `UPDATE users SET student_code = $1 || (1000 + id) WHERE student_code IS NULL`,
      [STUDENT_ID_PREFIX]
    );

    const ministries = ['স্বাস্থ্য অধিদপ্তর','শিক্ষা মন্ত্রণালয়','ভূমি মন্ত্রণালয়','খাদ্য অধিদপ্তর','ডাক অধিদপ্তর','সমাজসেবা অধিদপ্তর','পরিসংখ্যান ব্যুরো','প্রাথমিক শিক্ষা অধিদপ্তর'];
    for (const m of ministries) {
      await pool.query('INSERT INTO ministries(name) VALUES ($1) ON CONFLICT (name) DO NOTHING', [m]);
    }
    console.log('✅ Startup check complete.');
  } catch (err) {
    console.error('❌ autoInit failed:', err.message);
  }
}

module.exports = autoInit;
